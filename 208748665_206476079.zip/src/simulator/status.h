#pragma once

enum class Status {
    FINISH,
    WORKING,
    DEAD,
    TIMEOUT,
};